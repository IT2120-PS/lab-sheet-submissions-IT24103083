setwd("C:\\Users\\it24103083\\Desktop\\IT24103083")
getwd()
#01
branch_data <- read.table("Exercise.txt",header=TRUE,sep=",")
head(branch_data)

#02
#Types & scales:
#Branch: identifier(nominal)
#Scales_X1: quantitative, ratio
#Advertising_X2: quantitative, ratio
#Years_X3: quantitative discrete, ratio

#03
boxplot(Sales_X1,
        main="Box plot for sales",
        ylab="Sales_X1",
        outline=TRUE,
        outpch=8,
        horizontal=TRUE)


#04
quantile(Advertising_X2,
         probs = c(0, 0.25, 0.5, 0.75, 1))
IQR(Advertising_X2)

#05
get.outliers <- function(z){
  q1 <- quantile(z)[2]; q3 <- quantile(z)[4]; iqr <- q3 - q1
  lb <- q1 - 1.5*iqr; ub <- q3 + 105*iqr
  print(paste("Upper Bound = ",ub))
  print(paste("Lower Bound = ",lb))
  print(paste("Outliers:",paste(sort(z[z < lb | z > ub]), collapse = ", ")))
}
get.outliers(Years_X3)
